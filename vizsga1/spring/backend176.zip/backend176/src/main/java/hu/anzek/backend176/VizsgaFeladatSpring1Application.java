package hu.anzek.backend176;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VizsgaFeladatSpring1Application {

	public static void main(String[] args) {
		SpringApplication.run(VizsgaFeladatSpring1Application.class, args);
	}

}
