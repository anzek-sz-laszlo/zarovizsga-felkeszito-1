package hu.anzek.backend176;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VizsgaFeladatSpring1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
